from kubernetes import client, config
import os

def main():
    # Load kube config
    config.load_kube_config()

    # Define the namespace
    namespace = 'default'  # Replace with the actual namespace if different

    # Create Kubernetes API client
    v1 = client.CoreV1Api()

    # Log file name
    log_filename = 'all-pods-logs.txt'

    try:
        # List all pods in the specified namespace
        pods = v1.list_namespaced_pod(namespace)

        if not pods.items:
            print(f"No pods found in the {namespace} namespace.")
            # Append to the log file indicating no pods are found
            with open(log_filename, 'a') as log_file:
                log_file.write("No pods found in the namespace.\n")
            print(f"No pods log appended to {log_filename}")
        else:
            for pod in pods.items:
                pod_name = pod.metadata.name
                pod_status = pod.status.phase
                pod_deletion_timestamp = pod.metadata.deletion_timestamp
                pod_restart_count = pod.status.container_statuses[0].restart_count if pod.status.container_statuses else 0

                if pod_status != 'Running' or pod_deletion_timestamp is not None or pod_restart_count > 0:
                    status_msg = f"Pod {pod_name} is in {pod_status} state"
                    if pod_deletion_timestamp:
                        status_msg += " (Terminating)"
                    if pod_status == 'Pending':
                        status_msg += " (Pending)"
                    if pod_status == 'Failed':
                        status_msg += " (Failed)"
                    if pod_restart_count > 0:
                        status_msg += f" (Restart count: {pod_restart_count})"
                    
                    # Explicitly print the status message
                    print(status_msg)

                    # Fetch logs of the pod
                    try:
                        pod_logs = v1.read_namespaced_pod_log(name=pod_name, namespace=namespace)
                        # Append logs to the log file
                        with open(log_filename, 'a') as log_file:
                            log_file.write(f"\n--- Logs for pod {pod_name} ---\n")
                            log_file.write(pod_logs)
                            log_file.write("\n")
                        print(f"Logs appended to {log_filename}")
                    except client.exceptions.ApiException as e:
                        print(f"Failed to fetch logs for pod {pod_name}: {e}")
                else:
                    print(f"Pod {pod_name} is running smoothly")

    except client.exceptions.ApiException as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()

