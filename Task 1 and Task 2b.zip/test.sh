#!/bin/bash

# Docker Hub credentials
DOCKER_HUB_USERNAME="hardddyy"
DOCKER_HUB_PASSWORD="Ilikeyou12"

# Step 1: Install dependencies
echo "Updating package list and installing dependencies..."
sudo apt-get update
sudo apt-get install -y apt-transport-https ca-certificates curl conntrack

# Step 2: Install Docker
echo "Installing Docker..."
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
sudo apt-get update
sudo apt-get install -y docker-ce

# Step 3: Start Docker service
echo "Starting Docker service..."
sudo systemctl start docker
sudo systemctl enable docker

# Step 4: Log in to Docker Hub
echo "Logging in to Docker Hub..."
echo "${DOCKER_HUB_PASSWORD}" | docker login -u "${DOCKER_HUB_USERNAME}" --password-stdin

# Step 5: Build Docker image
echo "Building Docker image..."
docker build -t hardddyy/flask-app:latest .

# Step 6: Push Docker image to Docker Hub
echo "Pushing Docker image to Docker Hub..."
docker push hardddyy/flask-app:latest

# Step 7: Install Minikube
echo "Installing Minikube..."
curl -Lo minikube https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
sudo install minikube /usr/local/bin/

# Step 8: Start Minikube with Docker driver
echo "Starting Minikube..."
minikube start --driver=docker
minikube addons enable ingress

# Step 9: Install kubectl
echo "Installing kubectl..."
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# Step 10: Set up kubectl context
echo "Setting up kubectl context..."
minikube update-context

# Step 11: Deploy the Flask app
echo "Deploying the Flask app..."
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml

# Wait for pod readiness
echo "Waiting for pod readiness..."
kubectl wait --for=condition=ready pod -l app=flask-app --timeout=120s

# Step 12: Print deployment status
echo "Deployment status:"
kubectl get nodes
kubectl get pods --all-namespaces
kubectl get services --all-namespaces
kubectl get deployments --all-namespaces

echo "Setup complete! Your Flask app should be deployed and running."

# Fetch node internal IP and test the service
NODE_IP=$(kubectl get nodes -o wide | grep -m 1 -oP '(?<=\s)\d{1,3}(\.\d{1,3}){3}(?=\s)')
echo "Node IP: $NODE_IP"

if [[ $NODE_IP == *"."* ]]; then
  echo "Fetching from Node IP: http://$NODE_IP:32188"
  curl http://$NODE_IP:32188 || echo "Flask app not reachable"
else
  echo "Invalid Node IP address: $NODE_IP"
fi

